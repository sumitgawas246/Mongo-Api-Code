# MEAN4+ Starter

This project is based on the tutorial from [Coursetro.com](https://coursetro.com), located here:
[Setting up an Angular 4 MEAN Stack (Tutorial)](https://coursetro.com/posts/code/84/Setting-up-an-Angular-4-MEAN-Stack-(Tutorial))

Good luck!